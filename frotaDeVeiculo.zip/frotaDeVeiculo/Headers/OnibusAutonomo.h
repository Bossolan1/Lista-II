#pragma once
#include<iostream>
#include<string>
#include<vector>
#include"VeiculoAutonomo.h"
#include"Coordenada.h"
#include"Sensores.h"

class OnibusAutonomo : public VeiculoAutonomo
{
    private:
        std::string placa;
        int numeroPassageiros, capacidadeMax;
        std::vector<Coordenada> pontosDeParada;
        bool emUso;
    public:


    OnibusAutonomo(std::string id, float bateria, Coordenada partida, Coordenada chegada, Coordenada pontoAtual, Sensores sensor, std::string placa, int numeroPassageiros, int capacidadeMax, bool emUso, std::vector<Coordenada> pontosDeParada = {}) :
    VeiculoAutonomo(id,bateria,partida,chegada,pontoAtual,sensor), placa(placa), numeroPassageiros(numeroPassageiros), capacidadeMax(capacidadeMax), emUso(emUso), pontosDeParada(pontosDeParada)
    {std::cout << "Veiculo ' " << this->getID() << " ' criado com sucesso!" << std::endl;}
    
        void mover() override; 
        void planejarRota(Coordenada chegada) override;
        float calculaConsumo() override;
        void relatorioStatus() override;

    virtual ~OnibusAutonomo() {std::cout << "Veiculo ' " << this->getID() << " ' destruido com sucesso!" << std::endl ;}
};
