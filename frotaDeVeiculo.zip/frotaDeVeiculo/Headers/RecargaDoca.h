#pragma once
#include<string>
#include<iostream>
#include"EstrategiaRecarga.h"
#include"Coordenada.h"
class RecargaDoca : public EstrategiaRecarga
{
    private:

    public:
        void recarregar(float &bateria) override;
        std::string getTipo() const override;
        float getTempo() const override; //que haja poliformismo
        virtual ~RecargaDoca() = default; // melhor gerenciamento de memória para o mr compilador
};