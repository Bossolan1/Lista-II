#pragma once

#include<iostream>
#include<string>
#include"Coordenada.h"
#include"Sensores.h"
#include"EstrategiaRecarga.h"

class VeiculoAutonomo
{
    protected: 
        std::string id;
        float bateria;
        Coordenada partida;
        Coordenada chegada;
        Coordenada pontoAtual;
        Sensores sensor;
        
    public:
        VeiculoAutonomo(std::string id, float bateria, Coordenada partida, Coordenada chegada, Coordenada pontoAtual, Sensores sensor) :
        id(id), bateria(bateria), partida(partida), chegada(chegada), pontoAtual(pontoAtual), sensor(sensor)
        { std::cout << "Veiculo '" << id <<"' criado com sucesso!" << std::endl;}
        
        virtual void mover() = 0; //  responsabilidade de movimento apenas para o veículo;
        virtual void planejarRota(Coordenada chegada) = 0; // E a rota também, com possíveis alterações do despachante;
        virtual float calculaConsumo() = 0; // pois cada veiculo tem alguma coisa que muda para isso
        virtual void relatorioStatus() = 0; // Vai falicitar horrores depois
        
        float getBateria() const {return bateria;}  // esse pode ser genérico
        std::string getID() const  {return id;}

        virtual ~VeiculoAutonomo() { std::cout << "Veiculo '" << id << "' destruido com sucesso!" << std::endl;}

};