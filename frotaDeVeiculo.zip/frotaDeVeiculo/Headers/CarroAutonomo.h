#pragma once
#include<iostream>
#include<string>
#include"VeiculoAutonomo.h"

class CarroAutonomo : public VeiculoAutonomo
{
    private:
        std::string placa;
        int passageiros,capacidade;
        bool emUso;
    public:

    CarroAutonomo(std::string id, float bateria, Coordenada partida, Coordenada chegada, Coordenada pontoAtual, Sensores sensor, std::string placa, int passageiros, int capacidade, bool emUso) :
    VeiculoAutonomo(id,bateria,partida,chegada,pontoAtual,sensor), placa(placa), passageiros(passageiros), capacidade(capacidade), emUso(emUso)
    {std::cout << "Veiculo ' " << this->getID() << " ' criado com sucesso!" << std::endl;}
    
        void mover() override; 
        void planejarRota(Coordenada chegada) override;
        float calculaConsumo() override;
        void relatorioStatus() override;

    virtual ~CarroAutonomo() {std::cout << "Veiculo ' " << this->getID() << " ' destruido com sucesso!" << std::endl ;}
};