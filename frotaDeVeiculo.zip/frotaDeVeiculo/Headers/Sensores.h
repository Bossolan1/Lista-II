#pragma once
#include <string>
#include <iostream>

using namespace std;

class Sensores
{
    private:
        bool status;
        std::string id;
    public:    
        Sensores(bool status,std::string id) : status(status), id(id) {}

        std::string getID() const {return id;}
        bool getStatus() const {return status;}

        bool detectaObstaculo(); 

        ~Sensores() {}
};