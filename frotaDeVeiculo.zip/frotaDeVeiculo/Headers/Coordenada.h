#pragma once
#include<iostream>
#include<string>

class Coordenada
{
    private:
        float longitude, latitude;
    public:
        Coordenada(float longitude, float latitude): longitude(longitude), latitude(latitude) {};
        
        float getLongitude() const {return longitude;}
        float getLatitude() const {return latitude;}

        float calculaDistancia();
        ~Coordenada(){};
};