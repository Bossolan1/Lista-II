#pragma once
#include <string>
#include <iostream>

class EstrategiaRecarga // Interface; {só para garantir um contrato entre as interfaces e futuras expansõoes}
{ // motivos para isso não ter em outros códigos, é um porre implementar :D e desennhar um sistema
    public:
        virtual ~EstrategiaRecarga() = default; 
        virtual void recarregar(float &bateria) = 0;
        virtual std::string getTipo() const = 0;
        virtual float getTempo() const = 0;
};
