#pragma once

#include<string>
#include<iostream>
#include<vector>
#include<memory>
#include"EstacaoRecarga.h"

class Despachante
{
    private:
        std::string id;
        std::vector<std::unique_ptr<EstacaoRecarga>> estacoes;
        std::vector<std::unique_ptr<VeiculoAutonomo>> frota;

    public:
        Despachante(std::string id) : id(id) {std::cout << "Despachante '" << id << "' adicionado ao sistema" << std::endl;}

    
    void adicionarVeiculo(std::unique_ptr<VeiculoAutonomo> veiculo);
    void adicionarEstacao(std::unique_ptr<EstacaoRecarga> estacao);
    
    void gerencia_recarga();
    void gera_relatorio();
    void statusVeiculos();
    
     std::string getID() const { return id; }
    virtual ~Despachante() {std::cout << "Despachante '" << id << "' removido do sistema" << std::endl;}
};