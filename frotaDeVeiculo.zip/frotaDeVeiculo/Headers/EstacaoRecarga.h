#pragma once
#include <iostream>
#include <string>
#include <vector>
#include <memory>
#include <queue>
#include "Coordenada.h"
#include "EstrategiaRecarga.h"

class VeiculoAutonomo; //foward declaration para evitar loops e o compilador sofrer menos;

class EstacaoRecarga
{
    private: // acho que vai ser melhor do que protected, já que os tipos são só bases 
        Coordenada localizacao;
        int capacidade;
        std::string id; 
        std::vector<std::unique_ptr<EstrategiaRecarga>> estrategias; //agragação
        std::vector<VeiculoAutonomo*> veiculosRecarregando; //agragação
        std::queue<VeiculoAutonomo*> filaEspera; //agragação, fila foi escolihda por uma caracteristica, o carro que chega primeiro, entra para carregar primeiro, fifo
        //Duas estruturas de dados distintas, mas ambas com coleção heterogenicas
    public:
        EstacaoRecarga(Coordenada localizacao, std::string id, int capacidade) : localizacao(localizacao), id(id), capacidade(capacidade)
        {std::cout << "Estacao: '" << id << "' Criada com sucesso!" << std::endl;}

        bool adicionarVeiculo(VeiculoAutonomo* veiculo);
        void liberarVeiculo(VeiculoAutonomo* veiculo); 
        bool temVaga() const;
        void adicionarEstrategia(std::unique_ptr<EstrategiaRecarga> estrategia);

        virtual ~EstacaoRecarga() {std::cout << "Estacao:'" << id << "'destruida com sucesso!" << std::endl;}
};