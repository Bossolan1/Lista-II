#pragma once
#include<iostream>
#include<string>
#include"VeiculoAutonomo.h"
#include"Coordenada.h"
#include"Sensores.h"

class CaminhaoAutonomo : public VeiculoAutonomo
{
    private:
        std::string placa;
        float pesoCarga, limitePeso;
        bool emUso;
    public:

    CaminhaoAutonomo(std::string id, float bateria, Coordenada partida, Coordenada chegada, Coordenada pontoAtual, Sensores sensor, std::string placa, float pesoCarga, float limitePeso, bool emUso) :
    VeiculoAutonomo(id,bateria,partida,chegada,pontoAtual,sensor), placa(placa), pesoCarga(pesoCarga), limitePeso(limitePeso), emUso(emUso)
    {std::cout << "Veiculo ' " << this->getID() << " ' criado com sucesso!" << std::endl;}
    
        void mover() override; 
        void planejarRota(Coordenada chegada) override;
        float calculaConsumo() override;
        void relatorioStatus() override;

        float getPesoCarga() const {return pesoCarga;}
        float getlimitePeso() const {return limitePeso;}

    virtual ~CaminhaoAutonomo() {std::cout << "Veiculo ' " << this->getID() << " ' destruido com sucesso!" << std::endl ;}
};