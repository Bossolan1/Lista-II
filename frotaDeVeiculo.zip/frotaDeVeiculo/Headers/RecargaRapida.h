#pragma once
#include<string>
#include<iostream>
#include"EstrategiaRecarga.h"
#include"Coordenada.h"
class RecargaRapida : public EstrategiaRecarga
{
    private:

    public:
        void recarregar(float &bateria) override;
        std::string getTipo() const override;
        float getTempo() const override; 
        virtual ~RecargaRapida() = default; 
};