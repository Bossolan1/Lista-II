#include "Sensores.h"
#include <iostream>
#include <random> // não tive tempo de compreender completamente a lógica do a* para calcular rotas, ai eu resolvi só fingir que é uma api, que faz tudo e o sistema é bem simples

bool Sensores::detectaObstaculo() {
    // Simulação simples - 20% de chance de detectar obstáculo
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> distrib(1, 100);
    
    bool obstaculo = (distrib(gen) <= 20); // 20% de chance
    
    if (obstaculo) {
        std::cout << " Sensor " << id << " detectou obstáculo!" << std::endl;
    }
    
    return obstaculo;
}