#include "RecargaIndutiva.h"
#include <iostream>

void RecargaIndutiva::recarregar(float &bateria) {
    std::cout << "Recarga INDUTIVA: +25% em 1h" << std::endl;
    bateria = std::min(bateria + 25.0f, 100.0f);
}

std::string RecargaIndutiva::getTipo() const {
    return "Indutiva";
}

float RecargaIndutiva::getTempo() const {
    return 1.0f; // 1 hora
}