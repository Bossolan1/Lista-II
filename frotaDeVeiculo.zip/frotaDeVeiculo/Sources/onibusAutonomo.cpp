#include "OnibusAutonomo.h"
#include<string>
#include<iostream>
#include<memory>
#include<vector>

void OnibusAutonomo::mover() 
{
    if (bateria > 0 && !sensor.detectaObstaculo()) 
    {
        std::cout << " Ônibus " << id << " está se movendo..." << std::endl;
        bateria -= calculaConsumo();
    } else 
    {
        std::cout << " Ônibus " << id << " não pode se mover" << std::endl;
    }
}

void OnibusAutonomo::planejarRota(Coordenada destino) 
{
    this->chegada = destino; 
    
    std::cout << " Ônibus '" << id << "' planejando rota..." << std::endl;
    
    if (!pontosDeParada.empty()) {
        std::cout << " Rota otimizada com " << pontosDeParada.size() << " paradas pré-definidas" << std::endl;
        
        for (int i = 0; i < pontosDeParada.size(); i++) {
            std::cout << "   Parada " << (i + 1) << ": (" 
                      << pontosDeParada[i].getLatitude() << ", " 
                      << pontosDeParada[i].getLongitude() << ")" << std::endl;
        }
    } else {
        std::cout << " Rota direta sem paradas programadas" << std::endl;
    }
    

    if (emUso) {
        std::cout << " Rota verificada para acessibilidade" << std::endl;  
    }
    
    std::cout << " Rota planejada com sucesso!" << std::endl;
}

float OnibusAutonomo::calculaConsumo() 
{
    return 0.25f + (numeroPassageiros * 0.001f);
}

void OnibusAutonomo::relatorioStatus() 
{
    std::cout << "=== ÔNIBUS " << id << " ===" << std::endl;
    std::cout << "Placa: " << placa << std::endl;
    std::cout << "Bateria: " << bateria << "%" << std::endl;
    std::cout << "Passageiros: " << numeroPassageiros << "/" << capacidadeMax << std::endl;
}