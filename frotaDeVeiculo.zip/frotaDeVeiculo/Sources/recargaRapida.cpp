#include "RecargaRapida.h"
#include <iostream>

void RecargaRapida::recarregar(float &bateria) {
    std::cout << "⚡ Recarga RÁPIDA: 80% em 30min" << std::endl;
    bateria = std::min(bateria + 80.0f, 100.0f);
}

std::string RecargaRapida::getTipo() const {
    return "Rápida";
}

float RecargaRapida::getTempo() const {
    return 0.5f; 
}