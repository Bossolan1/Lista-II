#include "CarroAutonomo.h"
#include <iostream>

void CarroAutonomo::mover() 
{
    if (bateria > 0 && !sensor.detectaObstaculo()) 
    {
        std::cout << "Carro " << id << " está se movendo..." << std::endl;
        bateria -= calculaConsumo();
    } else 
    {
        std::cout << "Carro " << id << " não pode se mover" << std::endl;
    }
}

void CarroAutonomo::planejarRota(Coordenada destino) 
{
    chegada = destino;
    std::cout << "Carro " << id << " planejou rota para destino" << std::endl;
}

float CarroAutonomo::calculaConsumo() 
{
    return 0.5f + (passageiros * 0.1f);
}

void CarroAutonomo::relatorioStatus() 
{
    std::cout << "=== CARRO " << id << " ===" << std::endl;
    std::cout << "Placa: " << placa << std::endl;
    std::cout << "Bateria: " << bateria << "%" << std::endl;
    std::cout << "Passageiros: " << passageiros << "/" << capacidade << std::endl;
}
