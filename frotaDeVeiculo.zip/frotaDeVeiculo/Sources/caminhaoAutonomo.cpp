#include "CaminhaoAutonomo.h"
#include <iostream>

void CaminhaoAutonomo::mover() 
{
    if (bateria > 0 && !sensor.detectaObstaculo()) 
    {
        std::cout << "Caminhão " << id << " está se movendo..." << std::endl;
        bateria -= calculaConsumo();
    } else 
    {
        std::cout << "Caminhao " << id << " não pode se mover" << std::endl;
    }
}

void CaminhaoAutonomo::planejarRota(Coordenada destino) 
{
    chegada = destino;
    std::cout << "Calculando rota com '" << getlimitePeso() << "'t permitido" << std::endl;
    std::cout << "Caminhao '" << id << "' planejou rota para destino" << std::endl;
}

float CaminhaoAutonomo::calculaConsumo() 
{
    return 0.25f + (getPesoCarga() * 0.00001f); // e sim o caminhão tem que ser eificiente/ter bateria maior
}

void CaminhaoAutonomo::relatorioStatus() 
{
    float percentual = (pesoCarga / limitePeso) * 100; 
    std::cout << "=== Caminhao " << id << " ===" << std::endl;
    std::cout << "Placa: " << placa << std::endl;
    std::cout << "Bateria: " << bateria << "%" << std::endl;
    std::cout << "Carga: " << pesoCarga << "/" << limitePeso << "kg (" << percentual << "%)" << std::endl;
}
