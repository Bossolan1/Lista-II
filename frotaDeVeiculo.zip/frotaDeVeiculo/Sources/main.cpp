#include "Despachante.h"
#include "CarroAutonomo.h"
#include "CaminhaoAutonomo.h"
#include "OnibusAutonomo.h"
#include "EstacaoRecarga.h"
#include "RecargaRapida.h"
#include "RecargaDoca.h"
#include "RecargaIndutiva.h"
#include "Sensores.h"
#include "Coordenada.h"
#include <iostream>
#include <memory>
#include <vector>

int main() {
    std::cout << "=== SISTEMA DE FROTA AUTÔNOMA ===" << std::endl;
    
    // Criar despachante
    auto despachante = std::unique_ptr<Despachante>(new Despachante("DSP-CENTRAL"));
    
    // Criar estações de recarga
    auto estacaoRapida = std::unique_ptr<EstacaoRecarga>(new EstacaoRecarga(
        Coordenada(-23.5505, -46.6333), "Estação Rápida Centro", 2
    ));
    estacaoRapida->adicionarEstrategia(std::unique_ptr<RecargaRapida>(new RecargaRapida()));
    
    auto estacaoDoca = std::unique_ptr<EstacaoRecarga>(new EstacaoRecarga(
        Coordenada(-23.5510, -46.6340), "Doca Caminhões", 1
    ));
    estacaoDoca->adicionarEstrategia(std::unique_ptr<RecargaDoca>(new RecargaDoca()));
    
    // Criar veículos
    
    // 🚗 CARRO
    auto carro1 = std::unique_ptr<CarroAutonomo>(new CarroAutonomo(
        "CAR-001", 45.0f, 
        Coordenada(0, 0), Coordenada(10, 10), Coordenada(0, 0),
        Sensores(true, "SENSOR-CAR-001"),
        "ABC-1234", 2, 5, false
    ));
    
    // 🚛 CAMINHÃO
    auto caminhao1 = std::unique_ptr<CaminhaoAutonomo>(new CaminhaoAutonomo(
        "CAM-001", 80.0f,
        Coordenada(5, 5), Coordenada(20, 20), Coordenada(5, 5),
        Sensores(true, "SENSOR-CAM-001"),
        "CAM-5678", 5000.0f, 10000.0f, true
    ));
    
    // 🚌 ÔNIBUS
    std::vector<Coordenada> paradasOnibus = {
        Coordenada(2, 2),
        Coordenada(4, 4),
        Coordenada(6, 6),
        Coordenada(8, 8)
    };
    
    auto onibus1 = std::unique_ptr<OnibusAutonomo>(new OnibusAutonomo(
        "BUS-001", 60.0f,
        Coordenada(1, 1), Coordenada(15, 15), Coordenada(1, 1),
        Sensores(true, "SENSOR-BUS-001"),
        "BUS-9012", 25, 40, true,
        paradasOnibus
    ));
    
    // Adicionar ao sistema
    std::cout << "\n=== CONFIGURANDO SISTEMA ===" << std::endl;
    despachante->adicionarEstacao(std::move(estacaoRapida));
    despachante->adicionarEstacao(std::move(estacaoDoca));
    
    despachante->adicionarVeiculo(std::move(carro1));
    despachante->adicionarVeiculo(std::move(caminhao1));
    despachante->adicionarVeiculo(std::move(onibus1));
    
    // Testar o sistema
    std::cout << "\n=== TESTANDO FROTA ===" << std::endl;
    
    // Status inicial
    despachante->statusVeiculos();
    
    // Planejar rotas
    std::cout << "\n=== PLANEJAMENTO DE ROTAS ===" << std::endl;
    // Nota: Precisaríamos de acesso aos veículos individualmente para isso
    
    // Gerenciar recargas
    std::cout << "\n=== GERENCIAMENTO DE RECARGAS ===" << std::endl;
    despachante->gerencia_recarga();
    
    // Relatório final
    std::cout << "\n=== RELATÓRIO FINAL ===" << std::endl;
    despachante->gera_relatorio();
    
    std::cout << "\n=== SISTEMA ENCERRADO ===" << std::endl;
    return 0;
}