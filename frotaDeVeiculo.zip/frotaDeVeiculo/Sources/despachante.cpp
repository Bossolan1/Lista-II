#include "Despachante.h"
#include "VeiculoAutonomo.h"
#include "EstacaoRecarga.h"
#include <iostream>

void Despachante::adicionarVeiculo(std::unique_ptr<VeiculoAutonomo> veiculo) {
    frota.push_back(std::move(veiculo));
    std::cout << "✅ Veículo " << frota.back()->getID() << " adicionado à frota" << std::endl;
}

void Despachante::adicionarEstacao(std::unique_ptr<EstacaoRecarga> estacao) {
    estacoes.push_back(std::move(estacao));
    std::cout << "🔌 Estação adicionada ao sistema" << std::endl;
}

void Despachante::gerencia_recarga() {
    std::cout << "\n=== GERENCIANDO RECARGAS ===" << std::endl;
    for (auto& veiculo : frota) {
        if (veiculo->getBateria() < 30.0f) {
            std::cout << "🔋 Veículo " << veiculo->getID() << " precisa recarregar" << std::endl;
        }
    }
}

void Despachante::gera_relatorio() {
    std::cout << "\n=== RELATÓRIO GERAL ===" << std::endl;
    std::cout << "Frota: " << frota.size() << " veículos" << std::endl;
    std::cout << "Estações: " << estacoes.size() << " estações" << std::endl;
}

void Despachante::statusVeiculos() {
    std::cout << "\n=== STATUS DA FROTA ===" << std::endl;
    for (auto& veiculo : frota) {
        std::cout << "🚗 " << veiculo->getID() << " | Bateria: " << veiculo->getBateria() << "%" << std::endl;
    }
}