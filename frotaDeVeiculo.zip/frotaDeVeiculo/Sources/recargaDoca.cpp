#include "RecargaDoca.h"
#include <iostream>

void RecargaDoca::recarregar(float &bateria) 
{
    std::cout << "Recarga em DOCA: 100% em 2h" << std::endl;
    bateria = 100.0f;
}

std::string RecargaDoca::getTipo() const 
{
    return "Doca";
}

float RecargaDoca::getTempo() const 
{
    return 2.0f; // 2 horas
}