#include "EstacaoRecarga.h"
#include "VeiculoAutonomo.h"
#include <algorithm>
#include <iostream>


bool EstacaoRecarga::adicionarVeiculo(VeiculoAutonomo* veiculo) {
    if (veiculosRecarregando.size() < capacidade) {
        veiculosRecarregando.push_back(veiculo);
        std::cout << " Veículo " << veiculo->getID() 
                  << " começou a recarregar na estação " << id << std::endl;
        
        if (!estrategias.empty()) {
            float bateriaAtual = veiculo->getBateria();
            estrategias[0]->recarregar(bateriaAtual);
        }
        
        return true;
    } else {
        filaEspera.push(veiculo);
        std::cout << " Veículo " << veiculo->getID() 
                  << " entrou na fila da estação " << id 
                  << " (Posição: " << filaEspera.size() << ")" << std::endl;
        return false;
    }
}

void EstacaoRecarga::liberarVeiculo(VeiculoAutonomo* veiculo) {
    auto it = std::find(veiculosRecarregando.begin(), 
                       veiculosRecarregando.end(), veiculo);
    
    if (it != veiculosRecarregando.end()) {
        veiculosRecarregando.erase(it);
        std::cout << " Veículo " << veiculo->getID() 
                  << " liberou a estação " << id << std::endl;
        
        if (!filaEspera.empty()) {
            VeiculoAutonomo* proximo = filaEspera.front();
            filaEspera.pop();
            std::cout << " Chamando próximo da fila: " << proximo->getID() << std::endl;
            adicionarVeiculo(proximo);
        }
    }
}

bool EstacaoRecarga::temVaga() const {
    return veiculosRecarregando.size() < capacidade;
}

void EstacaoRecarga::adicionarEstrategia(std::unique_ptr<EstrategiaRecarga> estrategia) {
    estrategias.push_back(std::move(estrategia));
    std::cout << " Estratégia " << estrategias.back()->getTipo() 
              << " adicionada à estação " << id << std::endl;
}
