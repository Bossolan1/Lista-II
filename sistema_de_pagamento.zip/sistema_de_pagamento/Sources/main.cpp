#include <iostream>
#include <memory>
#include "Funcionario.h"
#include "Assalariado.h"
#include "Comissionado.h"
#include "Horista.h"
#include "FolhaDePagamento.h"

using namespace std;

int main() 
{
    cout << "=== SISTEMA DE FOLHA DE PAGAMENTO POGGERS ===\n" << endl;
    
    FolhaDePagamento folha;
    
    folha.adicionarFuncionario(make_unique<Assalariado>("001", "Maria", "123.456.789-00", "MG123456", 3000.0));
    folha.adicionarFuncionario(make_unique<Comissionado>("002", "Zé Vendas", "987.654.321-00", "SP654321", 50000.0, 5.0, 2000.0, true));
    folha.adicionarFuncionario(make_unique<Horista>("003", "João Horas", "111.222.333-44", "RJ789012", 1500.0, 160.0)); // 👈 COM AS HORAS!
    
    folha.processarFolha();g
    
    cout << "\n=== PRAISE THE SUN! === ☀️" << endl;
    
    return 0;
}