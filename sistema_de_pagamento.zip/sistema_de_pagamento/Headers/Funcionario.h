#pragma once
#include <iostream>
#include <vector>

using namespace std;
class Funcionario
{
    protected:
        string id, nome, cpf, rg;
    public:
        Funcionario(string id, string nome, string cpf, string rg) : id(id),nome(nome),cpf(cpf),rg(rg) 
        { cout << "Funcionario'" << nome << "' criado com sucesso!\n";}

        virtual ~Funcionario() {cout << "Funcionario'" << nome << "' destruido com sucesso\n";}

        virtual double calculaPagamento() = 0;
        virtual string gerarDemonstrativo() = 0;
};

// Para pegar as mãnhas; C++ Advanced  TheCherno  