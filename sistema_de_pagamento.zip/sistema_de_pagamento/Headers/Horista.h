// PRAISE THE SUN >:)
#pragma once
#include<iostream>
#include"Funcionario.h"
using namespace std;

class Horista : public Funcionario
{
    private:
        double salarioBase, horas_trabalhadas;
    public:
        Horista(string id, string nome, string cpf, string rg, double salarioBase, double horas_trabalhadas) : 
        Funcionario(id,nome,cpf,rg),salarioBase(salarioBase), horas_trabalhadas(horas_trabalhadas) {}

        virtual double calculaPagamento() override
        {
    
            double total_a_receber;
            if(horas_trabalhadas > 44)
            {
                total_a_receber = salarioBase + ((horas_trabalhadas - 44) * 7.99);
            }
            else
            {
                total_a_receber = salarioBase; 
            }
            return total_a_receber;
        }
    virtual string gerarDemonstrativo() override
    {
        string demonstrativo;
        demonstrativo += "Pagamento a ser realizado ao senhor(a) " + nome + "\n";
        demonstrativo += "Horas trabalhadas: " + to_string(horas_trabalhadas) + "\n";
        demonstrativo += "Salario base: " + to_string(salarioBase) + "\n";
        demonstrativo += "Total: " + to_string(calculaPagamento()) + "\n";
        return demonstrativo;
    }
    ~Horista() {}
};
