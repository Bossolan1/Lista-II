#pragma once
#include<iostream>
#include"Funcionario.h"
#include<vector>
using namespace std;

class FolhaDePagamento
{
    private:
        string id, cod;
        double total;
        vector<unique_ptr<Funcionario>> funcionarios;
    public:
        FolhaDePagamento() = default;

        void processarFolha()
        {
            cout << "Folha de pagamento!\n";
            for(auto& funcionario : funcionarios)
            {
                total += funcionario->calculaPagamento();
                cout << funcionario->gerarDemonstrativo() << endl;
            }
            cout << "Total da folha : R$ " <<  total << endl; 
        }
        void adicionarFuncionario(unique_ptr<Funcionario> funcionario)
        {
            funcionarios.push_back(move(funcionario));
        }
};