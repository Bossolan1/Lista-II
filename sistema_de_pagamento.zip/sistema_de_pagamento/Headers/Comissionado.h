// PRAISE THE SUN >:)
#pragma once
#include<iostream>
#include"Funcionario.h"
using namespace std;

class Comissionado : public Funcionario
{
    private:
        double vendas, percentual, salarioBase;
        bool temSalarioBase;
    public:
        Comissionado(string id, string nome, string cpf, string rg, double vendas, double percentual, double salarioBase, bool temSalarioBase) : 
        Funcionario(id,nome,cpf,rg),vendas(vendas), percentual(percentual), salarioBase(salarioBase), temSalarioBase(temSalarioBase) {}
        virtual double calculaPagamento() override
        {
            double total_a_receber;
            total_a_receber = (vendas * percentual/100) + (salarioBase * temSalarioBase);
            return total_a_receber;
        }
    virtual string gerarDemonstrativo() override
    {
        string demonstrativo;
        demonstrativo += "Pagamento a ser realizado ao senhor(a) " + nome + "\n";
        demonstrativo += "Salario base: " + to_string(salarioBase * temSalarioBase) + "\n";
        demonstrativo += "Vendas (percentual calculado): " + to_string(vendas * percentual/100) + "\n";
        demonstrativo += "Total: " + to_string(calculaPagamento()) + "\n";
        return demonstrativo;
    }
    ~Comissionado() {}
};
