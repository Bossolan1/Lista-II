// PRAISE THE SUN >:)
#pragma once
#include<iostream>
#include"Funcionario.h"
using namespace std;

class Assalariado : public Funcionario
{
    private:
        double salarioBase, bonus_mensal;
    public:
        Assalariado(string id, string nome, string cpf, string rg, double salarioBase) : 
        Funcionario(id,nome,cpf,rg),salarioBase(salarioBase) {}
        virtual double calculaPagamento() override
        {
            double total_a_receber;
            total_a_receber = salarioBase + bonus_mensal;
            return total_a_receber;
        }
    virtual string gerarDemonstrativo() override
    {
        string demonstrativo;
        demonstrativo += "Pagamento a ser realizado ao senhor(a) " + nome + "\n";
        demonstrativo += "Salario base: " + to_string(salarioBase) + "\n";
        demonstrativo +=" Bonus do mes: " + to_string(bonus_mensal) + "\n";
        return demonstrativo;
    }
    ~Assalariado() {}
};
