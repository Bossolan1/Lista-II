#pragma once
#include "Ferramenta.h"

class FerramentaDesenho : public Ferramenta {
public:
    void aplicar(Forma& forma) override;
    std::string nome() const override;
};