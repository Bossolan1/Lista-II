#pragma once
#include <vector>
#include <memory>
#include "Forma.h"
#include "Ferramenta.h"  
class Render {
private:
    std::vector<std::unique_ptr<Forma>> formas;
public:
    void adicionarForma(std::unique_ptr<Forma> forma);
    void renderizarTudo();
    void aplicarFerramenta(Ferramenta& ferramenta);
};