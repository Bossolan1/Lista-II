#pragma once
#include "Ferramenta.h"

class FerramentaExportar : public Ferramenta {
private:
    std::string formato;
public:
    FerramentaExportar(const std::string& formato);
    void aplicar(Forma& forma) override;
    std::string nome() const override;
};