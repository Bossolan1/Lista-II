#pragma once
#include "Ferramenta.h"

class FerramentaRedimensionar : public Ferramenta {
private:
    float fator;
public:
    FerramentaRedimensionar(float fator);
    void aplicar(Forma& forma) override;
    std::string nome() const override;
};