#pragma once
#include "Forma.h"

class Poligono : public Forma {
private:
    std::string nome_forma;
public:
    Poligono(std::string id, const std::vector<Ponto>& vertices, std::string nome_forma);
    void Desenhar() const override;
    void mover(float dx, float dy) override;
    float area() const override;
    float perimetro() const override;
    std::unique_ptr<Forma> clonar() const override;
};