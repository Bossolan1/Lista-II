#pragma once //bem bha
#include "Ferramenta.h"

class FerramentaValidar : public Ferramenta {
public:
    void aplicar(Forma& forma) override;
    std::string nome() const override;
};