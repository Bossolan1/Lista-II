#pragma once
#include "Ferramenta.h"

class FerramentaMover : public Ferramenta {
private:
    float dx, dy;
public:
    FerramentaMover(float dx, float dy);
    void aplicar(Forma& forma) override;
    std::string nome() const override;
};