#pragma once
#include <iostream>
#include <vector>
#include <memory>
#include <string>
#include "Forma.h"
#include "Ponto.h"


class Retangulo : public Forma
{
    private:
        float largura,altura;
    public:
        Retangulo(std::string id, Ponto Canto, float altura, float largura):
        Forma(id,{Canto}), altura(altura),largura(largura)
        {
            if(largura <= 0 || altura <= 0) throw std::invalid_argument("Largura/altura Inválida");
            std::cout << "Retangulo '" << id <<"' adicionado com sucesso" << std::endl;
        }     

    
    void Desenhar() const override;
    void mover(float dx, float dy) override;
    float area() const override;
    float perimetro() const override;
    std::unique_ptr<Forma> clonar() const override;
};