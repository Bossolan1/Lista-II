#pragma once
#include <iostream>
#include <vector>
#include <memory>
#include <string>
#include "Ponto.h"

class Forma
{
    protected:
        std::string id;
        std::vector<Ponto> pontos;
    public:
        Forma(std::string id, const std::vector<Ponto>& pontos) : id(id), pontos(pontos) {} //construtor de preguiçoso;
        virtual void Desenhar() const = 0; // ponto central para mover a figura, todas serão desenhadas por padrão com o centro em (0,0)
        virtual void mover(float dx, float dy) = 0; // caso ele queira desenhar em outro lugar, o calculo vai cer feito para mudar os pontos, com ele no centro; 
        virtual float area() const = 0; //arroz e feijão para a maior parte das figuras
        virtual float perimetro() const = 0; // mesma coisa
        virtual std::unique_ptr<Forma> clonar() const = 0; // deduzindo que vai clonar uma vez por chamada
        virtual ~Forma() = default; //boa prática gerenciar a memória automaticamente
};