#pragma once

class Ponto
{
    public:
        float px, py;
        Ponto(float px = 0, float py = 0) : px(px), py(py) {} //ponto default = (0,0)
};