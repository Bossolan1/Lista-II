#pragma once
#include <iostream>
#include <vector>
#include <memory>
#include <string>
#include "Forma.h"
#include "Ponto.h"

class Ponto;

class Circulo : public Forma
{
    private:
        float raio;
    public:
        Circulo(std::string id, Ponto centro,float raio):
        Forma(id, std::vector<Ponto>{centro}), raio(raio)
        {
            if(raio <= 0) throw std::invalid_argument("Raio deve ser maior que 0");
            std::cout << "Circulo '" << id <<"' adicionado com sucesso" << std::endl;
        }     

    
    void Desenhar() const override;
    void mover(float dx, float dy) override;
    float area() const override;
    float perimetro() const override;
    std::unique_ptr<Forma> clonar() const override;
};