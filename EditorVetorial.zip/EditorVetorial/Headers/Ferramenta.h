#pragma once
#include "Forma.h"
#include <memory>

class Ferramenta 
{
public:
    virtual ~Ferramenta() = default;
    virtual void aplicar(Forma& forma) = 0; // Habilita poliformismo, sendo um belo de um ponteiro 
    virtual std::string nome() const = 0;
};