#include "Retangulo.h"
#include <cmath>

void Retangulo::Desenhar() const
{
    std::cout << "Desenhando retangulo " << id 
              << " em (" << pontos[0].px << ", " << pontos[0].py << ")"
              << " [" << largura << "x" << altura << "]" << std::endl;
}

void Retangulo::mover(float dx, float dy) 
{
    pontos[0].px += dx;  
    pontos[0].py += dy;
}

float Retangulo::area() const
{
    return largura * altura;  
}

float Retangulo::perimetro() const
{
    return 2 * (largura + altura);  
}

std::unique_ptr<Forma> Retangulo::clonar() const
{
   return std::unique_ptr<Forma>(new Retangulo(*this)); 
}