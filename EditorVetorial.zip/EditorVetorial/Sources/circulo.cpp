#include "Circulo.h"
#include <cmath>

void Circulo::Desenhar() const
{
    std::cout << "Desenhando circulo" << std::endl;
}

void Circulo::mover(float dx, float dy) 
{
    //move o centro basicamente
    pontos[0].px += dx;
    pontos[0].py += dy;
}

float Circulo::area() const
{
    //melhor que colocar 3,14
    return M_PI * std::pow(raio, 2); // aqui poderia ser raio*raio, sim, mas se tem na biblioteca vou usar
}

float Circulo::perimetro() const
{
    return (2 * M_PI) * raio;
}

std::unique_ptr<Forma> Circulo::clonar() const 
{
    return std::unique_ptr<Forma>(new Circulo(*this));
}