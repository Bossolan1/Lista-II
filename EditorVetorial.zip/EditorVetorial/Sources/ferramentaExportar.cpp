#include "FerramentaExportar.h"

FerramentaExportar::FerramentaExportar(const std::string& formato) : formato(formato) {}

void FerramentaExportar::aplicar(Forma& forma) {
    std::cout << "📤 Exportando forma para " << formato << "..." << std::endl;
    // Aqui integraria com sistema de exportação real
}

std::string FerramentaExportar::nome() const {
    return "Ferramenta Exportar (" + formato + ")";
}