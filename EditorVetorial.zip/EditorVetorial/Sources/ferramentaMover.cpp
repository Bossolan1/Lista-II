#include "FerramentaMover.h"

FerramentaMover::FerramentaMover(float dx, float dy) : dx(dx), dy(dy) {}

void FerramentaMover::aplicar(Forma& forma) {
    std::cout << "🔄 Movendo forma: (" << dx << ", " << dy << ")" << std::endl;
    forma.mover(dx, dy);
}

std::string FerramentaMover::nome() const {
    return "Ferramenta Mover";
}