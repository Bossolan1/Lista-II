#include "FerramentaDesenho.h"

void FerramentaDesenho::aplicar(Forma& forma) {
    std::cout << "🎨 Desenhando forma..." << std::endl;
    forma.Desenhar();
}

std::string FerramentaDesenho::nome() const {
    return "Ferramenta Desenho";
}