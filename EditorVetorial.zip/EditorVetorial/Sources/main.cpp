#include <iostream>
#include <memory>
#include "Render.h"
#include "Circulo.h"
#include "Retangulo.h"
#include "Poligono.h"
#include "FerramentaMover.h"
#include "FerramentaDesenho.h"
#include "FerramentaValidar.h"
#include "FerramentaExportar.h"

int main() {
    // SIMPLES FRESCURA :D
    std::cout << "🚀 EDITOR VETORIAL - KISSANE POTATO EDITION 🥔" << std::endl;
    std::cout << "📅 " << __DATE__ << " | ⏰ " << __TIME__ << std::endl;
    std::cout << "=============================================\n" << std::endl;
    
    // 1. CRIAR RENDERER
    Render renderer;

    // 2. CRIAR FORMAS
    try {
        std::cout << " CRIANDO FORMAS..." << std::endl;
        
        // Círculo válido - C++11 style
        auto circulo = std::unique_ptr<Circulo>(new Circulo("circulo_1", Ponto(10, 10), 5.0f));
        
        // Retângulo válido - C++11 style  
        auto retangulo = std::unique_ptr<Retangulo>(new Retangulo("retangulo_1", Ponto(20, 30), 8.0f, 6.0f));
        
        // Polígono válido - C++11 style
        std::vector<Ponto> vertices = {Ponto(0,0), Ponto(10,0), Ponto(5,8)};
        auto triangulo = std::unique_ptr<Poligono>(new Poligono("poligono_1", vertices, "Triangulo"));

        // Adicionar ao renderer
        renderer.adicionarForma(std::move(circulo));
        renderer.adicionarForma(std::move(retangulo));
        renderer.adicionarForma(std::move(triangulo));

        std::cout << "Todas as formas criadas com sucesso!\n" << std::endl;

    } catch (const std::exception& e) {
        std::cout << "Erro ao criar forma: " << e.what() << std::endl;
        return 1;
    }

    // 3. APLICAR FERRAMENTAS
    FerramentaMover mover(5, 3);
    FerramentaDesenho desenho;
    FerramentaValidar validar;
    FerramentaExportar exportar("SVG");

    std::cout << "=== FASE 1: VALIDAÇÃO ===" << std::endl;
    renderer.aplicarFerramenta(validar);

    std::cout << "\n=== FASE 2: MOVIMENTO ===" << std::endl;
    renderer.aplicarFerramenta(mover);

    std::cout << "\n=== FASE 3: EXPORTAÇÃO ===" << std::endl;
    renderer.aplicarFerramenta(exportar);

    std::cout << "\n=== FASE 4: RENDERIZAÇÃO FINAL ===" << std::endl;
    renderer.renderizarTudo();

    return 0;
}

//seria bem mais simples para a versão 14, a maioria dos projetos foi a que eu usei, eu usei a 11 nesse, mas pelo amor de Deus Beto, essa versão é de 2011 cara, olha o trampo a mais que é usar isso aqui man, fora que esse make não tem lista manual cara, ele poderia fazer isso viu s2