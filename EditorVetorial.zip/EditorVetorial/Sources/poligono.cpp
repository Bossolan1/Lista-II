#include "Poligono.h"
#include <cmath>

Poligono::Poligono(std::string id, const std::vector<Ponto>& vertices, std::string nome_forma)
    : Forma(id, vertices), nome_forma(nome_forma)
{
    if(vertices.size() < 3) throw std::invalid_argument("Caro usuário, você não pode criar uma linha");
    std::cout << "Poligono '" << id <<"' adicionado com sucesso" << std::endl;
}

void Poligono::Desenhar() const {
    std::cout << "Desenhando " << nome_forma << " (Polígono com " 
              << pontos.size() << " vértices)" << std::endl;
}

void Poligono::mover(float dx, float dy) 
{
    for (auto& ponto : pontos) {
        ponto.px += dx;
        ponto.py += dy;
    }
}

float Poligono::area() const 
{
    // Fórmula do shoelace
    double area = 0.0;
    int n = pontos.size();
    for (int i = 0; i < n; i++) {
        int j = (i + 1) % n;
        area += (pontos[i].px * pontos[j].py - pontos[j].px * pontos[i].py);
    }
    return std::abs(area) / 2.0;
}

float Poligono::perimetro() const 
{
    double perimetro = 0.0;
    int n = pontos.size();
    for (int i = 0; i < n; i++) 
    {
        int j = (i + 1) % n;
        double dx = pontos[j].px - pontos[i].px;
        double dy = pontos[j].py - pontos[i].py;
        perimetro += std::sqrt(dx*dx + dy*dy);
    }
    return perimetro;
}

std::unique_ptr<Forma> Poligono::clonar() const {
    return std::unique_ptr<Forma>(new Poligono(*this));
}