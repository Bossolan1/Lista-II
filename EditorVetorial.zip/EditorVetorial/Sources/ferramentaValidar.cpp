#include "FerramentaValidar.h"

void FerramentaValidar::aplicar(Forma& forma) {
    std::cout << "✅ Validando forma..." << std::endl;
    // Poderia verificar área/perímetro > 0, etc.
    float a = forma.area();
    float p = forma.perimetro();
    std::cout << "Área: " << a << ", Perímetro: " << p << std::endl;
}

std::string FerramentaValidar::nome() const {
    return "Ferramenta Validar";
}