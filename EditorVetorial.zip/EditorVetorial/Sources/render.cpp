#include "Render.h"
#include "Ferramenta.h"

void Render::adicionarForma(std::unique_ptr<Forma> forma) {
    formas.push_back(std::move(forma));
}

void Render::renderizarTudo() {
    std::cout << "\n🎨 RENDERIZANDO TODAS AS FORMAS:\n";
    for (auto& forma : formas) {
        forma->Desenhar();
    }
}

void Render::aplicarFerramenta(Ferramenta& ferramenta) {
    std::cout << "\n🛠️ APLICANDO " << ferramenta.nome() << ":\n";
    for (auto& forma : formas) {
        ferramenta.aplicar(*forma);
    }
}