#include "FerramentaRedimensionar.h"
#include <stdexcept>

FerramentaRedimensionar::FerramentaRedimensionar(float fator) : fator(fator) {
    if (fator <= 0) throw std::invalid_argument("Fator deve ser > 0");
}

void FerramentaRedimensionar::aplicar(Forma& forma) {
    std::cout << "📏 Redimensionando forma com fator: " << fator << std::endl;
    // 🔥 PRECISAMOS ADICIONAR redimensionar() NA FORMA!
    // forma.redimensionar(fator); 
}

std::string FerramentaRedimensionar::nome() const {
    return "Ferramenta Redimensionar";
}