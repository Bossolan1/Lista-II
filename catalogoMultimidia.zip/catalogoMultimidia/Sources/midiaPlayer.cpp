#include<MidiaPlayer.h>

void MidiaPlayer::adicionarMidia(unique_ptr<Midia> midia)
{
    PlayList.push_back(move(midia));
}
    
void MidiaPlayer::PlayListPlayer()
{
    cout << "Playlist atual:" << NomePlayList << endl;
    for (auto& midia : PlayList) 
    {          
        midia->reproduzir();                
        midia->infodetalhada();
        cout << "-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=--=-=-=" << endl;
    }
}