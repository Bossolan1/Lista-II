#include "Musica.h"

void Musica::reproduzir()
{
    cout << "_________----------- Musicia -----------_________" << endl;
    cout << "Tocando agora: '" << titulo  << "'" << endl;
    cout << "Artista      : '" << artista << "'" << endl;
    cout << "Duracao      : '" << duracao << "'" << endl;
    cout << "-------------------------------------------------" << endl;
}
void Musica::infodetalhada()
{
    cout << "_________------------ Sobre ------------_________" << endl;
    cout << "Titulo : '" << titulo   << "'" << endl;
    cout << "Ano    : '" << ano      << "'" << endl;
    cout << "Artista: '" << artista  << "'" << endl;
    cout << "Album  : '" << album    << "'" << endl;
    cout << "BPM    : '" << bpm      << "'" << endl;
    cout << "Bitrate: '" << bitrate  << "'" << endl;
    cout << "Duracao: '" << duracao  << "'" << endl;
    cout << "-------------------------------------------------" << endl;
}