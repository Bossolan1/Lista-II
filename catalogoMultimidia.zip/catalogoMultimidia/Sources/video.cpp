#include "Video.h"

void Video::reproduzir()
{
    cout << "__________----------- Video -----------__________" << endl;
    cout << "Tocando agora: '" << titulo  << "'" << endl;
    cout << "Diretor      : '" << diretor << "'" << endl;
    cout << "Duracao      : '" << duracao << "'" << endl;
    cout << "--------------------------------------------------" << endl;
}
void Video::infodetalhada()
{
    cout << "_________------------ Sobre ------------_________" << endl;
    cout << "Titulo    : '" << titulo         << "'" << endl;
    cout << "Diretor   : '" << diretor        << "'" << endl;
    cout << "Distrib   : '" << distribuidora  << "'" << endl;
    cout << "Genero    : '" << genero         << "'" << endl;
    cout << "Duracao   : '" << duracao        << "'" << endl;
    cout << "Resolucao : '" << resolucao      << "'" << endl;
    cout << "Ano       : '" << ano            << "'" << endl;
    cout << "-------------------------------------------------" << endl;
}