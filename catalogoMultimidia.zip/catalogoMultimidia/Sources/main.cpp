#include <iostream>
#include <memory>
#include "MidiaPlayer.h"
#include "Musica.h"
#include "Video.h"
#include "Podcast.h"

using namespace std;

int main() 
{
    cout << "===  PLAYER List_b0x ===\n" << endl;
    
    MidiaPlayer player("SURTO001", "Session Caos Controlado"); // Instanciando playlist
    
    player.adicionarMidia(make_unique<Musica>( // unique_ptr do tipo múscia
        "Absolute Territory", "4:29", "2013", //construtor herdado +
        "Synthpop", "Ken Ashcorp", "126-252", "320", "Absolute Territory (single)" // Construtor da classe
    ));
    
    player.adicionarMidia(make_unique<Musica>(
        "Necro Culture Vulture", "3:42", "2018",
        "Breakcore", "Machine Girl", "142-284", "320", "The Ugly Art"
    ));
    
    player.adicionarMidia(make_unique<Musica>(
        "Pretty Cvnt", "3:41", "2022",
        "Digital Hardcore", "Sewerslvt", "87-174", "320", "Pretty Cvnt (single)"
    ));
    
    player.adicionarMidia(make_unique<Video>(
        "Pulp Fiction", "2:34:00", "1994",
        "1080p", "Quentin Tarantino", "Miramax", "Crime/Drama"
    ));
    
    player.adicionarMidia(make_unique<Video>(
        "Full Metal Jacket", "1:56:00", "1987", 
        "4K", "Stanley Kubrick", "Warner Bros", "Guerra/Drama"
    ));
    
    player.adicionarMidia(make_unique<Podcast>(
        "Fora da Curva", "58:15", "2024",
        "#47 - A nova cena independente brasileira", "Júlio Luna"
    ));
    
    player.adicionarMidia(make_unique<Podcast>(
        "Música da Alma", "42:30", "2023",
        "Especial: 10 bandas indie que você precisa conhecer", "Ana Costa"
    ));
    
    cout << "\n😵‍💫 INICIANDO PLAYLIST... 😵‍💫\n use sua imaginação :D\n" << endl;
    
    player.PlayListPlayer(); // Função de MidiaPlayer que chama detalhe e outro trem que eu esqueci o nome que é uma função void que sofre poliformismo;
    //se quiser achar o nome ta nos .cpp preguiça de olhar e eu só comentei essa bomba no dia seguintel;
    
    cout << "=== PRAISE THE CHAOS! 󰯇 ===" << endl; // or the sun 🌞
    
    return 0;
}

/*
 /\_/\  
 (-.-) 
  >^<
  b0x
*/