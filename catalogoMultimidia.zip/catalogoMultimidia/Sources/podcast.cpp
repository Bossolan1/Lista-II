#include "Podcast.h"

void Podcast::reproduzir()
{
    cout << "_________----------- Podcast -----------_________" << endl;
    cout << "Tocando agora: '" << titulo  << "'" << endl;
    cout << "Artista      : '" << host    << "'" << endl;
    cout << "Duracao      : '" << duracao << "'" << endl;
    cout << "-------------------------------------------------" << endl;
}
void Podcast::infodetalhada()
{
    cout << "_________------------ Sobre ------------_________" << endl;
    cout << "Titulo : '" << titulo   << "'" << endl;
    cout << "Host   : '" << host     << "'" << endl;
    cout << "Epsoio : '" << epsodio  << "'" << endl;
    cout << "Duracao: '" << duracao  << "'" << endl;
    cout << "Ano:     '" << ano      << "'" << endl;
    cout << "-------------------------------------------------" << endl;
}