#pragma once
#include <iostream>
#include "Midia.h"

using namespace std;

class Video : public Midia
{
    private:
        string resolucao, diretor, distribuidora, genero;
    public:
        Video(string titulo, string duracao, string ano, string resolucao, string diretor, string distribuidora, string genero) :
        Midia(titulo,duracao,ano), resolucao(resolucao), diretor(diretor), distribuidora(distribuidora), genero(genero)
        { cout << "Video '" << titulo << "' criado com sucesso!" << endl; }
        void reproduzir();
        void infodetalhada();
        ~Video() { cout << "Video '" << titulo << "' destruido com sucesso!" << endl; }
};