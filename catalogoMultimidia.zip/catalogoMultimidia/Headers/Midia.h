#pragma once

#include<iostream>
#include<vector>

using namespace std;

class Midia
{
    protected:
        string titulo, duracao, ano;
    public:
        Midia(string titulo,string duracao, string ano) : titulo(titulo), duracao(duracao), ano(ano)
        {cout << "Midia '" << titulo << "' Criada com sucesso!" << endl;}
        virtual void reproduzir() = 0;
        virtual void infodetalhada() = 0;
        ~Midia() {cout << "Midia '" << titulo << "' Criado com sucesso!" << endl;}
};