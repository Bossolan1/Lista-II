#pragma once
#include "Midia.h"

using namespace std;

class Podcast : public Midia
{
    protected:
        string epsodio, host;
    public:
        Podcast(string titulo, string duracao, string ano, string epsodio, string host) :
        Midia(titulo,duracao,ano), epsodio(epsodio), host(host) 
        { cout << "Podcast '" << titulo << "' criado com sucesso!"<< endl;}
        void reproduzir();
        void infodetalhada();
        ~Podcast() { cout << "Podcast '" << titulo << "' destruido com sucesso!"<< endl;}
};