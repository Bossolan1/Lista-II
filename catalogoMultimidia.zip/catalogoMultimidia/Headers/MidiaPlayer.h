#pragma once

#include<vector>
#include<memory>
#include<iostream>
#include"Midia.h"

using namespace std;

class MidiaPlayer
{
    private:
        string codPlaylist, NomePlayList;
        vector<unique_ptr<Midia>> PlayList;
    public:
        MidiaPlayer(string codPlaylist, string NomePlayList) : 
        codPlaylist(codPlaylist), NomePlayList(NomePlayList)
        { cout << "Playlist '" << NomePlayList << "' criada com sucesso!" << endl; }
        void adicionarMidia(unique_ptr<Midia> midia);  
        void PlayListPlayer(); 
        ~MidiaPlayer()  { cout << "Playlist '" << NomePlayList << "' destruida com sucesso!" << endl; }
};