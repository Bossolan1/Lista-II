#pragma once
#include"Midia.h"
#include<iostream>

using namespace std;

class Musica : public Midia
{
    private:
        string generoMusical, artista, bpm, bitrate, album;
    public:
        Musica(string titulo, string duracao, string ano, string generoMusical, string artista, string bpm, string bitrate, string album) :
        Midia(titulo,duracao,ano), generoMusical(generoMusical), artista(artista), bpm(bpm), bitrate(bitrate), album(album)
        {cout << "Musica '" << titulo << "' Adicionada!" << endl;}
        void reproduzir();
        void infodetalhada();
        ~Musica() {cout << "Musica '" << titulo << "' Removida!" << endl;}
};